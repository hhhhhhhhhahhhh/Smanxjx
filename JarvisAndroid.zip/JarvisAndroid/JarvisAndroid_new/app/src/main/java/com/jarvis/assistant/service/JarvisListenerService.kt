package com.jarvis.assistant.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.jarvis.assistant.ai.LocalLlmClient
import com.jarvis.assistant.core.LocalCommandParser
import com.jarvis.assistant.voice.SpeechManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Foreground service that handles push-to-talk voice commands: tap the mic
 * button, speak, and the recognized text is sent and replied to. Runs as a
 * foreground service so recording/replying keeps working even if the app's
 * UI briefly isn't visible. All command handling lives here (not in
 * MainActivity), so behavior stays identical whether or not the UI is open.
 * When MainActivity is open, it binds to this service to mirror the chat
 * and the orb's state; when it's not, the service just speaks replies directly.
 */
class JarvisListenerService : Service() {

    interface JarvisEventListener {
        fun onUserSpeech(text: String)
        fun onAssistantReply(text: String)
        fun onListeningStateChanged(listening: Boolean)
        fun onSpeakStateChanged(speaking: Boolean)
    }

    inner class LocalBinder : Binder() {
        fun getService(): JarvisListenerService = this@JarvisListenerService
    }

    private val binder = LocalBinder()
    private val listeners = mutableSetOf<JarvisEventListener>()

    fun addListener(l: JarvisEventListener) { listeners.add(l) }
    fun removeListener(l: JarvisEventListener) { listeners.remove(l) }

    private lateinit var speechManager: SpeechManager
    private lateinit var localLlm: LocalLlmClient
    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())

    private val systemPrompt =
        "Sen JARVIS'sin, telefonda çalışan kısa ve yardımsever bir Türkçe asistansın. Kısa ve net cevaplar ver."

    val isModelReady: Boolean
        get() = localLlm.isModelReady

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        speechManager = SpeechManager(applicationContext)
        localLlm = LocalLlmClient(applicationContext)
        startForegroundWithNotification()
        // Wire up TTS speaking-state callbacks (for the orb animation) without
        // enabling the old always-on "Jarvis" background listening loop —
        // voice input is now push-to-talk only (tap the mic button).
        speechManager.startContinuousListening(
            initiallyEnabled = false,
            onWakeResult = {},
            onListeningStateChanged = { listening -> listeners.forEach { it.onListeningStateChanged(listening) } },
            onSpeakStateChanged = { speaking -> listeners.forEach { it.onSpeakStateChanged(speaking) } },
            onErrorHeard = {}
        )
    }

    private fun startForegroundWithNotification() {
        val channelId = "jarvis_listener"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "JARVIS Dinleme", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("JARVIS hazır")
            .setContentText("Konuşmak için mikrofon ikonuna dokun.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    /**
     * Push-to-talk: listens for a single phrase (no wake word needed, since
     * tapping the mic button is already explicit intent) and handles it like
     * any other command. Safe to call even while background listening is on
     * or off.
     */
    fun pushToTalk() {
        speechManager.listenOnce(
            onResult = { text ->
                if (text.isBlank()) {
                    listeners.forEach { it.onAssistantReply("Bir şey duyamadım, tekrar dener misin?") }
                } else {
                    handleCommand(text)
                }
            },
            onListeningStateChanged = { listening -> listeners.forEach { it.onListeningStateChanged(listening) } },
            onError = { message -> listeners.forEach { it.onAssistantReply(message) } }
        )
    }

    /** Typed messages (from the chat input) skip the wake word — typing is already explicit intent. */
    fun sendTypedMessage(text: String) {
        handleCommand(text)
    }

    suspend fun importModel(uri: Uri): Boolean = localLlm.importModel(uri)

    fun cycleVoiceFromUI(): String = speechManager.cycleVoice()

    private fun handleCommand(command: String) {
        if (command.isBlank()) {
            listeners.forEach { it.onUserSpeech("Jarvis") }
            val reply = "Efendim?"
            listeners.forEach { it.onAssistantReply(reply) }
            speechManager.speak(reply)
            return
        }

        listeners.forEach { it.onUserSpeech(command) }
        val normalized = command.trim().lowercase()

        if (normalized.contains("sesi değiştir") || normalized.contains("sesini değiştir") ||
            normalized.contains("ses değiştir")
        ) {
            val reply = speechManager.cycleVoice()
            listeners.forEach { it.onAssistantReply(reply) }
            return
        }

        val localResult = LocalCommandParser.tryHandle(applicationContext, normalized)
        if (localResult != null) {
            listeners.forEach { it.onAssistantReply(localResult) }
            speechManager.speak(localResult)
            return
        }

        if (!localLlm.isModelReady) {
            val reply = "Bunu anlayamadım ve henüz yerel model seçilmedi."
            listeners.forEach { it.onAssistantReply(reply) }
            speechManager.speak(reply)
            return
        }

        serviceScope.launch {
            val reply = localLlm.reply(systemPrompt, command)
            listeners.forEach { it.onAssistantReply(reply) }
            speechManager.speak(reply)
        }
    }

    override fun onDestroy() {
        speechManager.stopContinuousListening()
        speechManager.destroy()
        super.onDestroy()
    }

    companion object {
        private const val NOTIFICATION_ID = 1
    }
}
