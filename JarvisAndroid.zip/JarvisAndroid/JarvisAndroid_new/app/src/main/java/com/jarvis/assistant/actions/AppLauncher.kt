package com.jarvis.assistant.actions

import android.content.Context
import android.content.Intent

object AppLauncher {

    /** Opens an installed app whose visible label best matches [query]. */
    fun open(context: Context, query: String): String {
        val pm = context.packageManager
        val launchables = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )

        val q = query.trim().lowercase()
        val match = launchables.firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(q)
        } ?: launchables.firstOrNull {
            q.contains(it.loadLabel(pm).toString().lowercase())
        }

        if (match == null) {
            return "\"$query\" adında yüklü bir uygulama bulamadım."
        }

        val appName = match.loadLabel(pm).toString()
        val launchIntent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            "$appName açılıyor."
        } else {
            "$appName bulundu ama açılamadı."
        }
    }
}
