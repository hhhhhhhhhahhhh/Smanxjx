package com.jarvis.assistant

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.widget.EditText
import android.widget.ImageButton
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.jarvis.assistant.core.ChatAdapter
import com.jarvis.assistant.core.ChatMessage
import com.jarvis.assistant.service.FloatingMicService
import com.jarvis.assistant.service.JarvisListenerService
import com.jarvis.assistant.ui.OrbView
import kotlinx.coroutines.launch

/**
 * JARVIS UI shell. Voice input is push-to-talk: tap the mic button, speak,
 * and the recognized text is sent automatically. All the actual
 * thinking/speaking happens in JarvisListenerService (a foreground service).
 * This Activity just binds to that service to mirror the chat and the orb.
 */
class MainActivity : AppCompatActivity(), JarvisListenerService.JarvisEventListener {

    private lateinit var adapter: ChatAdapter
    private lateinit var orbView: OrbView
    private lateinit var micButton: ImageButton
    private lateinit var overlayToggleButton: ImageButton
    private var service: JarvisListenerService? = null

    private val messages = mutableListOf<ChatMessage>()
    private val permissionRequestCode = 42

    private val helpText = """
        Şunları deneyebilirsin:
        • "Spotify aç", "Google aç"
        • "İstanbul'da hava durumu"
        • "Pil durumu", "ram durumu", "depolama durumu", "saat kaç"
        • "Ali'ye whatsapp'tan merhaba yaz"
        • "Böyle bir şarkı çal"
        • "14:30'da toplantı hatırlat"
        • "Sesi değiştir"
        Bunların dışındaki her şeyi telefonda çalışan yerel AI modeline soracağım.
    """.trimIndent()

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val bound = (binder as JarvisListenerService.LocalBinder).getService()
            service = bound
            bound.addListener(this@MainActivity)
            if (!bound.isModelReady) {
                addMessage(
                    "Serbest sohbet için bir yerel AI modeli seçmen gerekiyor. Yukarıdaki yükleme " +
                        "ikonuna dokunup, tarayıcından indirdiğin .litertlm model dosyasını seç.",
                    isUser = false
                )
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
        }
    }

    private val modelPickerLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        addMessage("Model dosyası kopyalanıyor, biraz sürebilir...", isUser = false)
        lifecycleScope.launch {
            val ok = service?.importModel(uri) ?: false
            addMessage(
                if (ok) "Yerel model hazır! Artık sabit komutlara uymayan her şeyi offline yanıtlayabilirim."
                else "Model dosyası okunamadı. Doğru .litertlm dosyasını seçtiğinden emin ol.",
                isUser = false
            )
        }
    }

    private val overlayPermissionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (Settings.canDrawOverlays(this)) {
            startFloatingBubble()
        } else {
            addMessage("İzin verilmediği için konuşma balonu açılamadı.", isUser = false)
        }
        updateOverlayButtonAppearance()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)
        requestRuntimePermissions()

        orbView = findViewById(R.id.orbView)
        orbView.setState(OrbView.State.IDLE)

        val recycler = findViewById<RecyclerView>(R.id.chatRecycler)
        adapter = ChatAdapter(messages)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        val input = findViewById<EditText>(R.id.messageInput)
        val sendButton = findViewById<ImageButton>(R.id.sendButton)
        micButton = findViewById(R.id.micButton)
        val voiceChangeButton = findViewById<ImageButton>(R.id.voiceChangeButton)
        val selectModelButton = findViewById<ImageButton>(R.id.selectModelButton)
        overlayToggleButton = findViewById(R.id.overlayToggleButton)
        updateOverlayButtonAppearance()

        addMessage(
            "Merhaba! Ben JARVIS. Mikrofon ikonuna dokun, konuş, bıraktığında söylediğin " +
                "otomatik olarak gönderilir. $helpText",
            isUser = false
        )

        selectModelButton.setOnClickListener {
            modelPickerLauncher.launch(arrayOf("*/*"))
        }

        overlayToggleButton.setOnClickListener {
            toggleFloatingBubble()
        }

        voiceChangeButton.setOnClickListener {
            val result = service?.cycleVoiceFromUI() ?: "Servis henüz hazır değil."
            addMessage(result, isUser = false)
        }

        sendButton.setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isNotEmpty()) {
                input.setText("")
                orbView.setState(OrbView.State.THINKING)
                service?.sendTypedMessage(text)
            }
        }

        micButton.setOnClickListener {
            if (!hasRecordAudioPermission()) {
                requestRuntimePermissions()
                return@setOnClickListener
            }
            orbView.setState(OrbView.State.LISTENING)
            service?.pushToTalk()
        }

        if (hasRecordAudioPermission()) {
            startListenerService()
        }
    }

    private fun hasRecordAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
    }

    /** Turns the floating "talk from any app" bubble on or off. */
    private fun toggleFloatingBubble() {
        if (FloatingMicService.isRunning) {
            stopService(Intent(this, FloatingMicService::class.java))
            addMessage("Konuşma balonu kapatıldı.", isUser = false)
            updateOverlayButtonAppearance()
            return
        }
        if (Settings.canDrawOverlays(this)) {
            startFloatingBubble()
        } else {
            addMessage(
                "Diğer uygulamaların (YouTube vb.) üzerinde küçük bir balon gösterebilmem için " +
                    "\"diğer uygulamaların üzerinde göster\" iznini açman gerekiyor.",
                isUser = false
            )
            overlayPermissionLauncher.launch(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
    }

    private fun startFloatingBubble() {
        ContextCompat.startForegroundService(this, Intent(this, JarvisListenerService::class.java))
        startService(Intent(this, FloatingMicService::class.java))
        addMessage(
            "Balon açık. Artık YouTube gibi başka bir uygulamadayken bile ekranda görünen " +
                "küçük yuvarlağa dokunup konuşabilirsin; sürükleyerek yerini değiştirebilirsin.",
            isUser = false
        )
        updateOverlayButtonAppearance()
    }

    private fun updateOverlayButtonAppearance() {
        val colorRes = if (FloatingMicService.isRunning) R.color.jarvis_accent else R.color.jarvis_text_dim
        overlayToggleButton.setColorFilter(ContextCompat.getColor(this, colorRes))
    }

    /** Starts the always-on foreground listener service (binding happens in onStart). */
    private fun startListenerService() {
        val intent = Intent(this, JarvisListenerService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequestCode && hasRecordAudioPermission()) {
            startListenerService()
            val intent = Intent(this, JarvisListenerService::class.java)
            bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
        }
    }

    // --- JarvisEventListener callbacks from the service ---

    override fun onUserSpeech(text: String) {
        runOnUiThread {
            addMessage(text, isUser = true)
            orbView.setState(OrbView.State.THINKING)
        }
    }

    override fun onAssistantReply(text: String) {
        runOnUiThread { addMessage(text, isUser = false) }
    }

    override fun onListeningStateChanged(listening: Boolean) {
        runOnUiThread { if (listening) orbView.setState(OrbView.State.LISTENING) }
    }

    override fun onSpeakStateChanged(speaking: Boolean) {
        runOnUiThread {
            orbView.setState(if (speaking) OrbView.State.SPEAKING else OrbView.State.IDLE)
        }
    }

    private fun addMessage(text: String, isUser: Boolean) {
        adapter.addMessage(ChatMessage(text, isUser))
        findViewById<RecyclerView>(R.id.chatRecycler).scrollToPosition(messages.size - 1)
    }

    private fun requestRuntimePermissions() {
        val needed = listOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CALENDAR,
            Manifest.permission.WRITE_CALENDAR,
            Manifest.permission.READ_CONTACTS
        ).let {
            if (android.os.Build.VERSION.SDK_INT >= 33) it + Manifest.permission.POST_NOTIFICATIONS else it
        }.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), permissionRequestCode)
        }
    }

    override fun onStop() {
        // The service keeps running (it was started, not just bound) — we only
        // stop mirroring its events while our UI isn't visible.
        try {
            service?.removeListener(this)
            unbindService(serviceConnection)
        } catch (e: Exception) {
            // not bound — ignore
        }
        super.onStop()
    }

    override fun onStart() {
        super.onStart()
        updateOverlayButtonAppearance()
        if (hasRecordAudioPermission()) {
            val intent = Intent(this, JarvisListenerService::class.java)
            bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
        }
    }
}
